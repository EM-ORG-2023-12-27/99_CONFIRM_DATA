package com.example.app.domain.user.dao;

import com.example.app.domain.common.Crud;
import com.example.app.domain.user.dto.User;

public interface UserDao extends Crud<User, String>{
}